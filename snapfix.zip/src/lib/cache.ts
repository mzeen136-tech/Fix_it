// Database query caching with performance optimizations
import { supabase } from '@/lib/supabase';

// ── Cache Types ──────────────────────────────────────────────────────────────

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number;
}

interface CacheStats {
  hits: number;
  misses: number;
  size: number;
}

// ── Cache Configuration ──────────────────────────────────────────────────────

class QueryCache {
  private cache = new Map<string, CacheEntry<any>>();
  private stats = { hits: 0, misses: 0, size: 0 };
  
  // TTL settings (in milliseconds)
  private readonly TTLs = {
    technicians: 5 * 60 * 1000,     // 5 minutes - tech data doesn't change often
    activeJobs: 2 * 60 * 1000,      // 2 minutes - jobs change more frequently
    customerJobs: 1 * 60 * 1000,    // 1 minute - customer-specific data
    tradeLookup: 10 * 60 * 1000,    // 10 minutes - trade lists rarely change
  };

  // ── Core Cache Operations ──────────────────────────────────────────────────

  private generateKey(table: string, query: any): string {
    const queryString = JSON.stringify(query);
    return `${table}_${this.hashString(queryString)}`;
  }

  private hashString(str: string): string {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // Convert to 32-bit integer
    }
    return Math.abs(hash).toString(36);
  }

  private isExpired(entry: CacheEntry<any>): boolean {
    return Date.now() - entry.timestamp > entry.ttl;
  }

  private set<T>(key: string, data: T, ttl: number): void {
    // Remove old entries if cache is getting too large
    if (this.cache.size > 1000) {
      this.cleanup();
    }

    this.cache.set(key, {
      data,
      timestamp: Date.now(),
      ttl
    });
    
    this.stats.size = this.cache.size;
  }

  private get<T>(key: string): T | null {
    const entry = this.cache.get(key);
    
    if (!entry) {
      this.stats.misses++;
      return null;
    }
    
    if (this.isExpired(entry)) {
      this.cache.delete(key);
      this.stats.misses++;
      return null;
    }
    
    this.stats.hits++;
    return entry.data;
  }

  // ── Cache Management ───────────────────────────────────────────────────────

  cleanup(): void {
    const now = Date.now();
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > entry.ttl) {
        this.cache.delete(key);
      }
    }
    this.stats.size = this.cache.size;
    console.log(`[Cache] Cleanup completed. ${this.cache.size} entries remaining.`);
  }

  clear(): void {
    this.cache.clear();
    this.stats = { hits: 0, misses: 0, size: 0 };
    console.log('[Cache] Cache cleared.');
  }

  getStats(): CacheStats {
    return { ...this.stats };
  }

  // ── Optimized Query Functions ──────────────────────────────────────────────

  async getTechniciansByTrade(trade: string, forceRefresh = false): Promise<any[]> {
    const cacheKey = `techs_by_trade_${trade}`;
    const ttl = this.TTLs.technicians;
    
    if (!forceRefresh) {
      const cached = this.get(cacheKey);
      if (cached) {
        console.log(`[Cache] Hit for technicians by trade: ${trade}`);
        return cached;
      }
    }

    console.log(`[Cache] Miss for technicians by trade: ${trade}`);
    
    const { data, error } = await supabase
      .from('technicians')
      .select('phone_number, name, trade, service_area, is_active')
      .eq('trade', trade)
      .eq('is_active', true)
      .order('created_at', { ascending: true });

    if (error) {
      console.error('[Cache] Database error for technicians:', error);
      throw error;
    }

    this.set(cacheKey, data, ttl);
    return data;
  }

  async getActiveJobsByTrade(trade: string, limit = 10, forceRefresh = false): Promise<any[]> {
    const cacheKey = `active_jobs_by_trade_${trade}_${limit}`;
    const ttl = this.TTLs.activeJobs;
    
    if (!forceRefresh) {
      const cached = this.get(cacheKey);
      if (cached) {
        console.log(`[Cache] Hit for active jobs by trade: ${trade}`);
        return cached;
      }
    }

    console.log(`[Cache] Miss for active jobs by trade: ${trade}`);
    
    const { data, error } = await supabase
      .from('active_jobs')
      .select('*')
      .eq('trade_required', trade)
      .eq('status', 'bidding')
      .order('created_at', { ascending: false })
      .limit(limit);

    if (error) {
      console.error('[Cache] Database error for active jobs:', error);
      throw error;
    }

    this.set(cacheKey, data, ttl);
    return data;
  }

  async getCustomerJobs(customerPhone: string, forceRefresh = false): Promise<any[]> {
    const cacheKey = `customer_jobs_${customerPhone}`;
    const ttl = this.TTLs.customerJobs;
    
    if (!forceRefresh) {
      const cached = this.get(cacheKey);
      if (cached) {
        console.log(`[Cache] Hit for customer jobs: ${customerPhone}`);
        return cached;
      }
    }

    console.log(`[Cache] Miss for customer jobs: ${customerPhone}`);
    
    const { data, error } = await supabase
      .from('active_jobs')
      .select('*')
      .eq('customer_phone', customerPhone)
      .order('created_at', { ascending: false });

    if (error) {
      console.error('[Cache] Database error for customer jobs:', error);
      throw error;
    }

    this.set(cacheKey, data, ttl);
    return data;
  }

  async getTradesList(forceRefresh = false): Promise<string[]> {
    const cacheKey = 'trades_list';
    const ttl = this.TTLs.tradeLookup;
    
    if (!forceRefresh) {
      const cached = this.get(cacheKey);
      if (cached) {
        console.log('[Cache] Hit for trades list');
        return cached;
      }
    }

    console.log('[Cache] Miss for trades list');
    
    const { data, error } = await supabase
      .from('technicians')
      .select('trade')
      .eq('is_active', true)
      .order('trade');

    if (error) {
      console.error('[Cache] Database error for trades list:', error);
      throw error;
    }

    const trades = Array.from(new Set(data?.map((item: any) => item.trade) || []));
    this.set(cacheKey, trades, ttl);
    return trades;
  }

  async checkIfTechnician(phone: string, forceRefresh = false): Promise<boolean> {
    const cacheKey = `is_tech_${phone}`;
    const ttl = this.TTLs.technicians;
    
    if (!forceRefresh) {
      const cached = this.get(cacheKey);
      if (cached !== null) {
        console.log(`[Cache] Hit for technician check: ${phone}`);
        return cached;
      }
    }

    console.log(`[Cache] Miss for technician check: ${phone}`);
    
    const { data, error } = await supabase
      .from('technicians')
      .select('phone_number')
      .eq('phone_number', phone)
      .eq('is_active', true)
      .maybeSingle();

    const isTech = !!data;
    
    this.set(cacheKey, isTech, ttl);
    return isTech;
  }

  async updateJobBids(jobId: string, bids: any[]): Promise<any> {
    // Invalidate cache for this specific job
    const cacheKeys = Array.from(this.cache.keys()).filter(key => key.includes(`job_${jobId}`) || key.includes(`customer_jobs_`));
    cacheKeys.forEach(key => this.cache.delete(key));
    
    console.log(`[Cache] Invalidated ${cacheKeys.length} keys for job ${jobId}`);

    const { data, error } = await supabase
      .from('active_jobs')
      .update({ 
        bids,
        updated_at: new Date().toISOString()
      })
      .eq('job_id', jobId)
      .select()
      .single();

    if (error) {
      console.error('[Cache] Database error updating job bids:', error);
      throw error;
    }

    return data;
  }

  // ── Performance Monitoring ─────────────────────────────────────────────────

  getPerformanceStats() {
    const stats = this.getStats();
    const hitRate = stats.hits + stats.misses > 0 
      ? ((stats.hits / (stats.hits + stats.misses)) * 100).toFixed(2)
      : '0';
    
    return {
      ...stats,
      hitRate: `${hitRate}%`,
      entries: Array.from(this.cache.entries()).map(([key, value]) => ({
        key,
        age: Date.now() - value.timestamp,
        ttl: value.ttl
      }))
    };
  }
}

// ── Singleton Export ──────────────────────────────────────────────────────

export const queryCache = new QueryCache();

// ── Utility Functions ─────────────────────────────────────────────────────────

// Periodic cleanup (call this from a cron job or interval)
export function startCacheCleanup(intervalMs = 5 * 60 * 1000): NodeJS.Timeout {
  console.log(`[Cache] Starting cleanup every ${intervalMs / 1000} seconds`);
  return setInterval(() => {
    queryCache.cleanup();
  }, intervalMs);
}

// Warm up cache with frequently accessed data
export async function warmUpCache(): Promise<void> {
  console.log('[Cache] Warming up cache...');
  
  try {
    // Pre-load trades list
    await queryCache.getTradesList();
    
    // Pre-load a few recent jobs
    await queryCache.getActiveJobsByTrade('Plumber', 5);
    await queryCache.getActiveJobsByTrade('Electrician', 5);
    
    console.log('[Cache] Cache warmup completed');
  } catch (error) {
    console.error('[Cache] Cache warmup failed:', error);
  }
}