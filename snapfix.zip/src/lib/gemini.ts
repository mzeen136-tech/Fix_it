import { GoogleGenerativeAI } from "@google/generative-ai";

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY!);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// ── Simple in-memory cache ─────────────────────────────────────────────────────
const extractionCache = new Map<string, { result: any; timestamp: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

// ── Types ─────────────────────────────────────────────────────────────────────

export interface JobExtraction {
  trade: string;       // e.g. "Plumber", "Electrician", "HVAC"
  summary: string;     // one sentence
}

export interface BidExtraction {
  price: string;       // e.g. "Rs. 2500"
  eta: string;         // e.g. "45 minutes"
}

// ── Cache helper ──────────────────────────────────────────────────────────────

function getCachedResult(cacheKey: string): any | null {
  const cached = extractionCache.get(cacheKey);
  if (!cached) return null;
  
  if (Date.now() - cached.timestamp > CACHE_TTL) {
    extractionCache.delete(cacheKey);
    return null;
  }
  
  return cached.result;
}

function setCachedResult(cacheKey: string, result: any): void {
  extractionCache.set(cacheKey, {
    result,
    timestamp: Date.now()
  });
}

// ── Flow 2: Extract trade + summary from customer message ─────────────────────

export async function extractJobDetails(
  messageText: string
): Promise<JobExtraction> {
  if (!messageText || messageText.trim().length === 0) {
    return { trade: "Other", summary: "No description provided" };
  }

  // Create cache key from message content
  const cacheKey = `job_${messageText.slice(0, 100).replace(/\s+/g, '_')}`;
  
  // Check cache first
  const cached = getCachedResult(cacheKey);
  if (cached) {
    console.log(`[Gemini] Cache hit for job extraction`);
    return cached;
  }

  const prompt = `You are a home services dispatcher. Extract the trade and problem from this customer message.

Customer message: "${messageText}"

Respond with ONLY valid JSON in this exact format, no markdown, no explanation:
{"trade": "Plumber", "summary": "One sentence description of the problem"}

Trade must be exactly one of: Plumber, Electrician, HVAC, Carpenter, Painter, Other
Summary must be one sentence, under 100 characters.`;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text().trim();

    const extraction: JobExtraction = JSON.parse(text);
    
    // Validate and normalize
    const validTrades = ["Plumber", "Electrician", "HVAC", "Carpenter", "Painter", "Other"];
    extraction.trade = validTrades.includes(extraction.trade) ? extraction.trade : "Other";
    extraction.summary = extraction.summary.slice(0, 100);

    // Cache result
    setCachedResult(cacheKey, extraction);
    
    console.log(`[Gemini] Job extracted: ${extraction.trade} - ${extraction.summary}`);
    return extraction;
    
  } catch (error) {
    console.error("[Gemini] Failed to parse job extraction:", error);
    console.log("[Gemini] Raw response:", result.response.text());
    
    // Fallback with caching
    const fallback: JobExtraction = { 
      trade: "Other", 
      summary: messageText.slice(0, 100) 
    };
    setCachedResult(cacheKey, fallback);
    return fallback;
  }
}

// ── Flow 3: Extract price + ETA from technician bid ───────────────────────────

export async function extractBidDetails(
  messageText: string
): Promise<BidExtraction> {
  if (!messageText || messageText.trim().length === 0) {
    return { price: "Not specified", eta: "Not specified" };
  }

  // Create cache key from message content
  const cacheKey = `bid_${messageText.slice(0, 50).replace(/\s+/g, '_')}`;
  
  // Check cache first
  const cached = getCachedResult(cacheKey);
  if (cached) {
    console.log(`[Gemini] Cache hit for bid extraction`);
    return cached;
  }

  const prompt = `A technician is replying to a job posting. Extract their quoted price and estimated arrival time.

Technician message: "${messageText}"

Respond with ONLY valid JSON in this exact format, no markdown, no explanation:
{"price": "Rs. 2500", "eta": "30 minutes"}

If price is unclear write "Not specified". If ETA is unclear write "Not specified".`;

  try {
    const result = await model.generateContent(prompt);
    const text = result.response.text().trim();

    const extraction: BidExtraction = JSON.parse(text);
    
    // Normalize and validate
    extraction.price = extraction.price.trim() || "Not specified";
    extraction.eta = extraction.eta.trim() || "Not specified";

    // Cache result
    setCachedResult(cacheKey, extraction);
    
    console.log(`[Gemini] Bid extracted: ${extraction.price} - ${extraction.eta}`);
    return extraction;
    
  } catch (error) {
    console.error("[Gemini] Failed to parse bid extraction:", error);
    
    // Fallback with caching
    const fallback: BidExtraction = { 
      price: "Not specified", 
      eta: "Not specified" 
    };
    setCachedResult(cacheKey, fallback);
    return fallback;
  }
}

// ── Performance monitoring ─────────────────────────────────────────────────────

export function getCacheStats() {
  return {
    size: extractionCache.size,
    entries: Array.from(extractionCache.entries()).map(([key, value]) => ({
      key,
      timestamp: value.timestamp,
      age: Date.now() - value.timestamp
    }))
  };
}

// ── Cache cleanup ─────────────────────────────────────────────────────────────

export function cleanupCache(): void {
  const now = Date.now();
  for (const [key, value] of extractionCache.entries()) {
    if (now - value.timestamp > CACHE_TTL) {
      extractionCache.delete(key);
    }
  }
  console.log(`[Gemini] Cache cleanup completed. ${extractionCache.size} entries remaining.`);
}