import { supabase, Bid } from "@/lib/supabase";
import { extractBidDetails } from "@/lib/gemini";
import { sendWhatsAppMessage } from "@/lib/whatsapp";

export async function handleTechnicianBid(
  techPhone: string,
  messageText: string
): Promise<void> {
  console.log(`[Flow3] Tech bid from ${techPhone}: ${messageText}`);
  
  try {
    // 1. Get tech's info with validation
    const { data: tech } = await supabase
      .from("technicians")
      .select("name, trade")
      .eq("phone_number", techPhone)
      .eq("is_active", true)
      .single();

    if (!tech) {
      console.log(`[Flow3] Inactive/non-existent tech: ${techPhone}`);
      await sendWhatsAppMessage(
        techPhone,
        "❌ Your account is not active or not found. Please contact support."
      );
      return;
    }

    console.log(`[Flow3] Valid technician: ${tech.name} (${tech.trade})`);

    // 2. Find the most recent bidding job for this trade
    const { data: job } = await supabase
      .from("active_jobs")
      .select("*")
      .eq("trade_required", tech.trade)
      .eq("status", "bidding")
      .order("created_at", { ascending: false })
      .limit(1)
      .single();

    if (!job) {
      console.log(`[Flow3] No active bidding jobs for ${tech.trade}`);
      await sendWhatsAppMessage(
        techPhone,
        "ℹ️ No active jobs found for your trade right now. Check back later."
      );
      return;
    }

    console.log(`[Flow3] Found job ${job.job_id} for bidding`);

    // 3. Parse bid with Gemini
    const { price, eta } = await extractBidDetails(messageText);
    console.log(`[Flow3] Extracted bid: ${price}, ${eta}`);

    // 4. Check if tech has already bid on this job
    const existingBid = job.bids?.find((bid: Bid) => bid.tech_phone === techPhone);
    if (existingBid) {
      await sendWhatsAppMessage(
        techPhone,
        `⚠️ You've already bid on this job:\nPrice: ${existingBid.price}\nETA: ${existingBid.eta}\n\nTo update your bid, send a new message with your updated price and ETA.`
      );
      return;
    }

    // 5. Append bid to JSONB array with validation
    const newBid: Bid = {
      tech_phone: techPhone,
      tech_name: tech.name,
      price: price.trim(),
      eta: eta.trim(),
      received_at: new Date().toISOString(),
    };

    const updatedBids: Bid[] = [...(job.bids || []), newBid];

    const { error: updateError } = await supabase
      .from("active_jobs")
      .update({ 
        bids: updatedBids,
        updated_at: new Date().toISOString() // Add updated_at for better tracking
      })
      .eq("job_id", job.job_id);

    if (updateError) {
      console.error("[Flow3] Failed to update bids:", updateError);
      await sendWhatsAppMessage(
        techPhone,
        "❌ Failed to submit your bid. Please try again."
      );
      return;
    }

    // 6. Notify customer with bid details
    const customerMessage =
      `💬 New bid from *${tech.name}* (${tech.trade}):\n` +
      `💰 Price: ${newBid.price}\n` +
      `⏱ ETA: ${newBid.eta}\n\n` +
      `Reply *ACCEPT ${tech.name}* to hire them.`;

    try {
      await sendWhatsAppMessage(job.customer_phone, customerMessage);
    } catch (customerSendError) {
      console.error("[Flow3] Failed to notify customer:", customerSendError);
      // Don't fail the bid if customer notification fails
    }

    // 7. Confirm to tech
    const techConfirmMessage = 
      `✅ Your bid has been sent to the customer!\n` +
      `Price: ${newBid.price}\n` +
      `ETA: ${newBid.eta}\n\n` +
      `You'll be notified if they accept your bid.`;

    await sendWhatsAppMessage(techPhone, techConfirmMessage);
    
    console.log(`[Flow3] Bid from ${tech.name} submitted on job ${job.job_id}`);
    
  } catch (error) {
    console.error("[Flow3] Unexpected error:", error);
    
    // Try to send error message to tech
    try {
      await sendWhatsAppMessage(
        techPhone,
        "❌ Sorry, something went wrong processing your bid. Please try again."
      );
    } catch (sendError) {
      console.error("[Flow3] Failed to send error to tech:", sendError);
    }
  }
}