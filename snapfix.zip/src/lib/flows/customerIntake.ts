import { supabase } from "@/lib/supabase";
import { extractJobDetails } from "@/lib/gemini";
import { broadcastWhatsAppMessage, sendWhatsAppMessage } from "@/lib/whatsapp";

export async function handleCustomerIntake(
  customerPhone: string,
  messageText: string
): Promise<void> {
  console.log(`[Flow2] Customer intake from ${customerPhone}: ${messageText}`);
  
  try {
    // 1. Acknowledge receipt immediately
    const ackMessage = "⏳ Got it! We're finding available technicians for you. Hang tight...";
    await sendWhatsAppMessage(customerPhone, ackMessage);

    // 2. Parse with Gemini
    const { trade, summary } = await extractJobDetails(messageText);
    console.log(`[Flow2] Extracted: ${trade} - ${summary}`);

    // 3. Insert job with error handling
    const { data: job, error: jobError } = await supabase
      .from("active_jobs")
      .insert({
        customer_phone: customerPhone,
        trade_required: trade,
        problem_summary: summary,
        status: "bidding",
        bids: [],
      })
      .select()
      .single();

    if (jobError || !job) {
      console.error("[Flow2] Job insert failed:", jobError);
      await sendWhatsAppMessage(customerPhone, "❌ Something went wrong creating your job. Please try again.");
      return;
    }

    console.log(`[Flow2] Job ${job.job_id} created for ${trade}`);

    // 4. Find matching active technicians with optimized query
    const { data: techs, error: techError } = await supabase
      .from("technicians")
      .select("phone_number, name")
      .eq("trade", trade)
      .eq("is_active", true)
      .order("created_at", { ascending: true }); // Oldest first for fairness

    if (techError || !techs || techs.length === 0) {
      console.log(`[Flow2] No active ${trade}s available`);
      await sendWhatsAppMessage(
        customerPhone,
        `😔 Sorry, no ${trade}s are available in your area right now. We'll notify you when one becomes available.`
      );
      return;
    }

    console.log(`[Flow2] Found ${techs.length} available ${trade}s`);

    // 5. Broadcast to all matching techs with rate limiting
    const jobAlert =
      `🚨 NEW JOB ALERT\n` +
      `Customer: ${customerPhone}\n` +
      `Trade: ${trade}\n` +
      `Problem: ${summary}\n\n` +
      `Reply with your price and ETA to bid.\n` +
      `Example: "Rs. 2500, 30 minutes"`;

    try {
      await broadcastWhatsAppMessage(
        techs.map((t) => t.phone_number),
        jobAlert
      );
    } catch (broadcastError) {
      console.error("[Flow2] Broadcast failed:", broadcastError);
      // Don't fail the entire flow if broadcast fails
      await sendWhatsAppMessage(customerPhone, "✅ Technicians notified. You'll receive bids shortly.");
      return;
    }

    // 6. Confirm to customer
    await sendWhatsAppMessage(
      customerPhone,
      `✅ We've notified ${techs.length} ${trade}(s). You'll receive bids shortly.\n` +
      `Reply *ACCEPT [Name]* to hire someone.`
    );

    console.log(`[Flow2] Job ${job.job_id} created, ${techs.length} techs notified.`);
    
  } catch (error) {
    console.error("[Flow2] Unexpected error:", error);
    
    // Try to send error message if possible
    try {
      await sendWhatsAppMessage(
        customerPhone,
        "❌ Sorry, something went wrong while processing your request. Please try again."
      );
    } catch (sendError) {
      console.error("[Flow2] Failed to send error message:", sendError);
    }
  }
}