import { supabase } from "@/lib/supabase";
import { sendWhatsAppMessage } from "@/lib/whatsapp";

// Trigger: sender is ADMIN_PHONE and message starts with /add
// Format: /add Trade, Name, PhoneNumber, ServiceArea

export async function handleAdminCommand(
  adminPhone: string,
  messageText: string
): Promise<void> {
  console.log(`[Flow1] Admin command from ${adminPhone}: ${messageText}`);
  
  // Validate admin phone
  if (adminPhone !== process.env.ADMIN_PHONE) {
    console.warn(`[Flow1] Unauthorized admin attempt from ${adminPhone}`);
    return;
  }

  const parts = messageText.replace("/add", "").split(",").map((s) => s.trim());

  if (parts.length < 4) {
    await sendWhatsAppMessage(
      adminPhone,
      "❌ Invalid format. Use:\n/add Trade, Name, 923001234567, City"
    );
    return;
  }

  const [trade, name, phone_number, service_area] = parts;

  // Validate phone number format (basic check)
  if (!phone_number.match(/^923\d{9}$/)) {
    await sendWhatsAppMessage(
      adminPhone,
      "❌ Invalid phone number. Use format: 923001234567"
    );
    return;
  }

  // Validate trade
  const validTrades = ["Plumber", "Electrician", "HVAC", "Carpenter", "Painter", "Other"];
  if (!validTrades.includes(trade)) {
    await sendWhatsAppMessage(
      adminPhone,
      `❌ Invalid trade. Use one of: ${validTrades.join(", ")}`
    );
    return;
  }

  try {
    // Check if technician already exists
    const { data: existingTech } = await supabase
      .from("technicians")
      .select("phone_number")
      .eq("phone_number", phone_number)
      .maybeSingle();

    if (existingTech) {
      await sendWhatsAppMessage(
        adminPhone,
        `⚠️ Technician with phone ${phone_number} already exists. Use a different number.`
      );
      return;
    }

    // Insert new technician
    const { error } = await supabase.from("technicians").insert({
      phone_number,
      name,
      trade,
      service_area,
      is_active: true,
    });

    if (error) {
      console.error("[Flow1] Supabase insert error:", error);
      await sendWhatsAppMessage(adminPhone, `❌ Failed to add ${name}: ${error.message}`);
      return;
    }

    await sendWhatsAppMessage(
      adminPhone,
      `✅ ${name} added as ${trade} (${service_area}). Phone: ${phone_number}`
    );

    console.log(`[Flow1] Successfully added technician: ${name} (${phone_number})`);
    
  } catch (error) {
    console.error("[Flow1] Unexpected error:", error);
    await sendWhatsAppMessage(adminPhone, "❌ An unexpected error occurred. Please try again.");
  }
}