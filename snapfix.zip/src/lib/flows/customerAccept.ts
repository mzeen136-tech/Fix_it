import { supabase } from "@/lib/supabase";
import { sendWhatsAppMessage } from "@/lib/whatsapp";

export async function handleCustomerAcceptance(
  customerPhone: string,
  messageText: string
): Promise<void> {
  console.log(`[Flow4] Customer acceptance from ${customerPhone}: ${messageText}`);
  
  try {
    // Parse: "ACCEPT Ali" or "accept ali"
    const parts = messageText.trim().split(/\s+/);
    const acceptedName = parts.slice(1).join(" ").trim();

    if (!acceptedName) {
      await sendWhatsAppMessage(
        customerPhone,
        '❌ Please specify the technician name. Example: *ACCEPT Ali*'
      );
      return;
    }

    console.log(`[Flow4] Looking for bid from: ${acceptedName}`);

    // Find the customer's most recent bidding job
    const { data: job } = await supabase
      .from("active_jobs")
      .select("*")
      .eq("customer_phone", customerPhone)
      .eq("status", "bidding")
      .order("created_at", { ascending: false })
      .limit(1)
      .single();

    if (!job) {
      console.log(`[Flow4] No active bidding job found for customer ${customerPhone}`);
      await sendWhatsAppMessage(customerPhone, "❌ No active job found to accept bids for.");
      return;
    }

    console.log(`[Flow4] Found job ${job.job_id} for acceptance`);

    // Find the matching bid (case-insensitive name match)
    const matchedBid = job.bids?.find(
      (b: { tech_name: string }) =>
        b.tech_name.toLowerCase() === acceptedName.toLowerCase()
    );

    if (!matchedBid) {
      console.log(`[Flow4] No bid found from "${acceptedName}" in job ${job.job_id}`);
      await sendWhatsAppMessage(
        customerPhone,
        `❌ No bid found from "${acceptedName}". Check the name and try again. Available bids:\n` +
        job.bids?.map((b: any) => `• ${b.tech_name}: ${b.price}, ${b.eta}`).join('\n') || "No bids yet"
      );
      return;
    }

    console.log(`[Flow4] Matched bid from ${matchedBid.tech_name}`);

    // Check if job is already assigned (race condition protection)
    if (job.status === "assigned") {
      await sendWhatsAppMessage(
        customerPhone,
        "❌ This job has already been assigned to another technician."
      );
      return;
    }

    // Update job status to assigned
    const { error: updateError } = await supabase
      .from("active_jobs")
      .update({
        status: "assigned",
        assigned_tech_phone: matchedBid.tech_phone,
        updated_at: new Date().toISOString()
      })
      .eq("job_id", job.job_id);

    if (updateError) {
      console.error("[Flow4] Failed to update job status:", updateError);
      await sendWhatsAppMessage(customerPhone, "❌ Failed to assign technician. Please try again.");
      return;
    }

    // Handshake messages - send to both parties
    const techWinMessage =
      `🎉 Congratulations! You won the job!\n` +
      `Customer phone: *${customerPhone}*\n` +
      `Problem: ${job.problem_summary}\n\n` +
      `Please contact them within 10 minutes to confirm arrival and discuss details.\n` +
      `Good luck! 🛠️`;

    const customerConfirmMessage =
      `✅ *${matchedBid.tech_name}* has been confirmed as your technician!\n` +
      `Their phone: *${matchedBid.tech_phone}*\n` +
      `Price: ${matchedBid.price}\n` +
      `ETA: ${matchedBid.eta}\n\n` +
      `They'll contact you shortly to confirm arrival. Good luck! 🔧`;

    // Send to technician
    try {
      await sendWhatsAppMessage(matchedBid.tech_phone, techWinMessage);
      console.log(`[Flow4] Sent win notification to ${matchedBid.tech_name}`);
    } catch (techSendError) {
      console.error("[Flow4] Failed to notify winning tech:", techSendError);
      // Don't fail the assignment if tech notification fails
    }

    // Send to customer
    try {
      await sendWhatsAppMessage(customerPhone, customerConfirmMessage);
      console.log(`[Flow4] Sent confirmation to customer ${customerPhone}`);
    } catch (customerSendError) {
      console.error("[Flow4] Failed to notify customer:", customerSendError);
      // Don't fail the assignment if customer notification fails
    }

    // Log the successful assignment
    console.log(`[Flow4] Job ${job.job_id} assigned to ${matchedBid.tech_name}`);
    
    // Optional: Send assignment notification to admin (if needed)
    if (process.env.ADMIN_PHONE) {
      try {
        const adminNotification = `📋 Job Assignment:\nJob ID: ${job.job_id}\nCustomer: ${customerPhone}\nTechnician: ${matchedBid.tech_name}\nTrade: ${job.trade_required}\nPrice: ${matchedBid.price}`;
        await sendWhatsAppMessage(process.env.ADMIN_PHONE, adminNotification);
      } catch (adminError) {
        console.error("[Flow4] Failed to notify admin:", adminError);
      }
    }
    
  } catch (error) {
    console.error("[Flow4] Unexpected error:", error);
    
    // Try to send error message to customer
    try {
      await sendWhatsAppMessage(
        customerPhone,
        "❌ Sorry, something went wrong while accepting the bid. Please try again."
      );
    } catch (sendError) {
      console.error("[Flow4] Failed to send error to customer:", sendError);
    }
  }
}