import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.SUPABASE_URL!;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;

// Singleton — Next.js hot-reload safe
export const supabase = createClient(supabaseUrl, supabaseKey, {
  auth: { persistSession: false },
});

// ── Types ────────────────────────────────────────────────────────────────────

export interface Technician {
  phone_number: string;
  name: string;
  trade: string;
  service_area: string;
  is_active: boolean;
  created_at: string;
}

export interface Bid {
  tech_phone: string;
  tech_name: string;
  price: string;
  eta: string;
  received_at: string;
}

export interface ActiveJob {
  job_id: string;
  customer_phone: string;
  trade_required: string;
  problem_summary: string;
  status: "bidding" | "assigned" | "completed";
  bids: Bid[];
  assigned_tech_phone: string | null;
  created_at: string;
}