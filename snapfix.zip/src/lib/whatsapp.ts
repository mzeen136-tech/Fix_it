const WHATSAPP_API_URL = `https://graph.facebook.com/v19.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`;
const ACCESS_TOKEN = process.env.WHATSAPP_ACCESS_TOKEN!;

// ── Core sender with retry logic and error handling ─────────────────────────────

export async function sendWhatsAppMessage(
  to: string,
  message: string,
  retries: number = 3
): Promise<void> {
  const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));
  
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const res = await fetch(WHATSAPP_API_URL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${ACCESS_TOKEN}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          messaging_product: "whatsapp",
          to,
          type: "text",
          text: { body: message },
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        
        if (res.status === 429) {
          // Rate limiting - exponential backoff
          const waitTime = Math.pow(2, attempt) * 1000;
          console.log(`[WhatsApp] Rate limited. Waiting ${waitTime}ms (attempt ${attempt}/${retries})`);
          await delay(waitTime);
          continue;
        }
        
        if (res.status >= 500 && attempt < retries) {
          // Server error - retry
          console.log(`[WhatsApp] Server error on attempt ${attempt}/${retries}`);
          await delay(Math.pow(2, attempt) * 1000);
          continue;
        }
        
        console.error(`[WhatsApp] Failed to send to ${to}:`, err);
        throw new Error(`WhatsApp send failed: ${JSON.stringify(err)}`);
      }

      // Success
      console.log(`[WhatsApp] Message sent to ${to}`);
      return;
      
    } catch (err) {
      if (attempt === retries) {
        console.error(`[WhatsApp] Failed after ${retries} attempts to ${to}:`, err);
        throw err;
      }
      
      // Network error - retry after delay
      console.log(`[WhatsApp] Network error on attempt ${attempt}/${retries}`);
      await delay(Math.pow(2, attempt) * 1000);
    }
  }
}

// ── Broadcast helper with concurrency control ──────────────────────────────────

export async function broadcastWhatsAppMessage(
  recipients: string[],
  message: string,
  concurrency: number = 5
): Promise<void> {
  console.log(`[WhatsApp] Broadcasting to ${recipients.length} recipients with concurrency ${concurrency}`);
  
  // Send in batches to avoid overwhelming the API
  const batches = [];
  for (let i = 0; i < recipients.length; i += concurrency) {
    batches.push(recipients.slice(i, i + concurrency));
  }

  await Promise.all(
    batches.map(batch => 
      Promise.all(batch.map(phone => sendWhatsAppMessage(phone, message)))
    )
  );
}

// ── Message validation ─────────────────────────────────────────────────────────

export function validateWhatsAppMessage(text: string): boolean {
  if (!text || typeof text !== 'string') return false;
  
  // Basic WhatsApp message validation
  const trimmed = text.trim();
  if (trimmed.length === 0 || trimmed.length > 1600) return false;
  
  return true;
}