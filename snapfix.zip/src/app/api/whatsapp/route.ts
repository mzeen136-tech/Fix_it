import { NextRequest, NextResponse } from "next/server";
import { supabase } from "@/lib/supabase";
import { queryCache } from "@/lib/cache";
import { handleAdminCommand } from "@/lib/flows/adminCommand";
import { handleCustomerIntake } from "@/lib/flows/customerIntake";
import { handleTechnicianBid } from "@/lib/flows/technicianBid";
import { handleCustomerAcceptance } from "@/lib/flows/customerAccept";

// ── GET — Meta webhook verification ──────────────────────────────────────────

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const mode = searchParams.get("hub.mode");
  const token = searchParams.get("hub.verify_token");
  const challenge = searchParams.get("hub.challenge");

  console.log(`[SnapFix] Webhook verification request: mode=${mode}, token=${token?.substring(0, 5) || 'none'}`);

  if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    console.log("[SnapFix] ✅ Webhook verified by Meta");
    return new NextResponse(challenge, { status: 200 });
  }

  console.warn("[SnapFix] ❌ Webhook verification failed");
  return new NextResponse("Forbidden", { status: 403 });
}

// ── POST — Incoming message router with performance monitoring ───────────────

export async function POST(req: NextRequest) {
  const startTime = Date.now();
  
  try {
    const body = await req.json();
    console.log(`[SnapFix] Received webhook at ${new Date().toISOString()}`);

    // Extract message from Meta's nested payload
    const message = body?.entry?.[0]?.changes?.[0]?.value?.messages?.[0];

    // Ignore delivery receipts, read notifications, etc.
    if (!message) {
      console.log("[SnapFix] Received non-message event - ignoring");
      return NextResponse.json({ status: "ok" }, { status: 200 });
    }

    const senderPhone: string = message.from;
    const messageText: string = message.text?.body?.trim() ?? "";
    const messageType: string = message.type; // text | image | audio

    console.log(`[SnapFix] Message from ${senderPhone}: "${messageText}" (${messageType})`);

    // Basic validation
    if (!senderPhone || !messageText) {
      console.warn("[SnapFix] Invalid message data - missing phone or text");
      return NextResponse.json({ status: "ok" }, { status: 200 });
    }

    // ── Identity checks with cached queries ───────────────────────────────

    const isAdmin = senderPhone === process.env.ADMIN_PHONE;

    // Use cached query to check if user is a technician
    let isTech = false;
    let isAccept = false;

    if (!isAdmin) {
      try {
        isTech = await queryCache.checkIfTechnician(senderPhone);
        isAccept = messageText.toUpperCase().startsWith("ACCEPT");
      } catch (error) {
        console.error("[SnapFix] Cache check failed:", error);
        // Fallback to direct query
        const { data: techRow } = await supabase
          .from("technicians")
          .select("phone_number")
          .eq("phone_number", senderPhone)
          .maybeSingle();
        isTech = !!techRow;
      }
    }

    console.log(`[SnapFix] Identity check - Admin: ${isAdmin}, Tech: ${isTech}, Accept: ${isAccept}`);

    // ── Route (order is critical) ────────────────────────────────────────────

    if (isAdmin && messageText.startsWith("/add")) {
      console.log("[SnapFix] Routing to Flow 1 - Admin command");
      await handleAdminCommand(senderPhone, messageText);

    } else if (!isTech && !isAdmin && isAccept) {
      // Customer ACCEPT — must come before generic customer intake
      console.log("[SnapFix] Routing to Flow 4 - Customer acceptance");
      await handleCustomerAcceptance(senderPhone, messageText);

    } else if (!isTech && !isAdmin) {
      // New customer message
      console.log("[SnapFix] Routing to Flow 2 - Customer intake");
      await handleCustomerIntake(senderPhone, messageText);

    } else if (isTech && !isAccept) {
      // Technician bid reply
      console.log("[SnapFix] Routing to Flow 3 - Technician bid");
      await handleTechnicianBid(senderPhone, messageText);

    } else {
      console.log(`[SnapFix] Unrouted message from ${senderPhone}: "${messageText}" (${messageType})`);
    }

    // Log performance and cache stats
    const processingTime = Date.now() - startTime;
    const cacheStats = queryCache.getPerformanceStats();
    
    console.log(`[SnapFix] Request processed in ${processingTime}ms`);
    console.log(`[SnapFix] Cache stats - Hit rate: ${cacheStats.hitRate}, Entries: ${cacheStats.size}`);

    // Always return 200 — Meta will disable your webhook on repeated failures
    return NextResponse.json({ 
      status: "ok", 
      processing_time_ms: processingTime,
      cache_stats: cacheStats
    }, { status: 200 });

  } catch (err) {
    const processingTime = Date.now() - startTime;
    console.error("[SnapFix] Webhook error:", err);
    console.log(`[SnapFix] Failed request processed in ${processingTime}ms`);
    
    // Still return 200 so Meta doesn't retry + disable your webhook
    return NextResponse.json({ 
      status: "error", 
      error: err instanceof Error ? err.message : "Unknown error",
      processing_time_ms: processingTime 
    }, { status: 200 });
  }
}

// ─── Health check endpoint for monitoring ─────────────────────────────────────

export async function OPTIONS(req: NextRequest) {
  return new NextResponse(null, { 
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    }
  });
}