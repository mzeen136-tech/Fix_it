-- =============================================
-- SNAPFIX DATABASE SETUP
-- Run this in Supabase SQL Editor
-- =============================================

-- 1. Create the technicians table
CREATE TABLE public.technicians (
  phone_number  TEXT PRIMARY KEY,          -- format: 923001234567
  name          TEXT        NOT NULL,
  trade         TEXT        NOT NULL,      -- e.g. Plumber, Electrician, HVAC
  service_area  TEXT        NOT NULL,
  is_active     BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 2. Create the active_jobs table
CREATE TABLE public.active_jobs (
  job_id             UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_phone     TEXT        NOT NULL,
  trade_required     TEXT        NOT NULL,
  problem_summary    TEXT        NOT NULL,
  status             TEXT        NOT NULL DEFAULT 'bidding'
                       CHECK (status IN ('bidding', 'assigned', 'completed')),
  bids               JSONB       NOT NULL DEFAULT '[]'::jsonb,
  assigned_tech_phone TEXT,
  created_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at         TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- =============================================
-- ROW LEVEL SECURITY (RLS)
-- Our server uses the service_role key, which
-- bypasses RLS entirely — so we enable RLS to
-- block any accidental anon/public access while
-- our backend keeps full unrestricted access.
-- =============================================

ALTER TABLE public.technicians  ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.active_jobs  ENABLE ROW LEVEL SECURITY;

-- No policies = no public access.
-- service_role key (used server-side) bypasses
-- RLS automatically. Zero extra config needed.

-- =============================================
-- PERFORMANCE OPTIMIZED INDEXES
-- =============================================

-- Fast lookup: "is this sender a technician?"
CREATE INDEX idx_technicians_phone ON public.technicians (phone_number);

-- Fast lookup: active technicians by trade
CREATE INDEX idx_technicians_trade_active ON public.technicians (trade, is_active) WHERE is_active = true;

-- Fast lookup: latest bidding job for a trade
CREATE INDEX idx_jobs_trade_status_created ON public.active_jobs (trade_required, status, created_at DESC);

-- Fast lookup: jobs by customer (for customer acceptance)
CREATE INDEX idx_jobs_customer_status ON public.active_jobs (customer_phone, status);

-- Fast lookup: assigned jobs by technician
CREATE INDEX idx_jobs_assigned_tech ON public.active_jobs (assigned_tech_phone) WHERE status = 'assigned';

-- Composite index for bidding jobs (most common query pattern)
CREATE INDEX idx_jobs_bidding_trade_created ON public.active_jobs (status, trade_required, created_at DESC) 
WHERE status = 'bidding';

-- Index on updated_at for cleanup operations
CREATE INDEX idx_jobs_updated_at ON public.active_jobs (updated_at);

-- Full text search for problem summaries (future enhancement)
CREATE INDEX idx_jobs_problem_summary ON public.active_jobs USING gin(to_tsvector('english', problem_summary));

-- =============================================
-- TRIGGERS FOR AUTOMATIC UPDATED_AT
-- =============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION handle_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply triggers to both tables
CREATE TRIGGER handle_technicians_updated_at
  BEFORE UPDATE ON public.technicians
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();

CREATE TRIGGER handle_active_jobs_updated_at
  BEFORE UPDATE ON public.active_jobs
  FOR EACH ROW
  EXECUTE FUNCTION handle_updated_at();

-- =============================================
-- DATA VALIDATION CONSTRAINTS
-- =============================================

-- Add check constraint for valid phone numbers
ALTER TABLE public.technicians 
ADD CONSTRAINT chk_phone_number_format 
CHECK (phone_number ~ '^923\d{9}$');

-- Add check constraint for valid trades
ALTER TABLE public.technicians 
ADD CONSTRAINT chk_valid_trade 
CHECK (trade IN ('Plumber', 'Electrician', 'HVAC', 'Carpenter', 'Painter', 'Other'));

-- Add constraint for job status transitions
CREATE OR REPLACE FUNCTION validate_job_status_transition()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.status = 'completed' AND NEW.status != 'completed' THEN
    RAISE EXCEPTION 'Cannot change job status from completed to other states';
  ELSIF OLD.status = 'assigned' AND NEW.status = 'bidding' THEN
    RAISE EXCEPTION 'Cannot change job status from assigned back to bidding';
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER validate_job_status_transition_trigger
  BEFORE UPDATE ON public.active_jobs
  FOR EACH ROW
  EXECUTE FUNCTION validate_job_status_transition();

-- =============================================
-- SAMPLE DATA FOR TESTING
-- =============================================

-- Insert sample technicians (only for testing - remove in production)
INSERT INTO public.technicians (phone_number, name, trade, service_area, is_active) VALUES
('923001234567', 'Ali', 'Plumber', 'Islamabad', true),
('923008765432', 'Ahmed', 'Electrician', 'Lahore', true),
('923003456789', 'Faisal', 'HVAC', 'Karachi', true),
('923007654321', 'Asad', 'Painter', 'Islamabad', true);

-- =============================================
-- VIEW FOR ACTIVE BIDDING JOBS (OPTIMIZED QUERY)
-- =============================================

CREATE OR REPLACE VIEW active_bidding_jobs AS
SELECT 
  job_id,
  customer_phone,
  trade_required,
  problem_summary,
  created_at,
  bids,
  jsonb_array_length(bids) as bid_count
FROM public.active_jobs
WHERE status = 'bidding'
ORDER BY created_at DESC;

-- =============================================
-- CLEANUP FUNCTION (FOR MAINTENANCE)
-- =============================================

-- Clean up completed jobs older than 30 days
CREATE OR REPLACE FUNCTION cleanup_old_jobs()
RETURNS void AS $$
BEGIN
  DELETE FROM public.active_jobs 
  WHERE status = 'completed' AND updated_at < NOW() - INTERVAL '30 days';
  
  RAISE NOTICE 'Cleanup completed. Removed old completed jobs.';
END;
$$ LANGUAGE plpgsql;

-- =============================================
-- ANALYTICS FUNCTIONS (PERFORMANCE MONITORING)
-- =============================================

-- Function to get system statistics
CREATE OR REPLACE FUNCTION get_system_stats()
RETURNS TABLE(
  total_technicians INTEGER,
  active_technicians INTEGER,
  total_jobs INTEGER,
  bidding_jobs INTEGER,
  assigned_jobs INTEGER,
  completed_jobs INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    (SELECT COUNT(*) FROM public.technicians),
    (SELECT COUNT(*) FROM public.technicians WHERE is_active = true),
    (SELECT COUNT(*) FROM public.active_jobs),
    (SELECT COUNT(*) FROM public.active_jobs WHERE status = 'bidding'),
    (SELECT COUNT(*) FROM public.active_jobs WHERE status = 'assigned'),
    (SELECT COUNT(*) FROM public.active_jobs WHERE status = 'completed');
END;
$$ LANGUAGE plpgsql;

-- =============================================
-- USAGE EXAMPLES
-- =============================================

-- Example: Find all active plumbers in Islamabad
-- SELECT phone_number, name FROM technicians WHERE trade = 'Plumber' AND service_area = 'Islamabad' AND is_active = true;

-- Example: Get all bidding jobs for electricians
-- SELECT * FROM active_jobs WHERE status = 'bidding' AND trade_required = 'Electrician' ORDER BY created_at DESC;

-- Example: Get system statistics
-- SELECT * FROM get_system_stats();

-- =============================================
-- END OF SCRIPT
-- =============================================