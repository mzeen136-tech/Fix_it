// ─── Gemini Clean + Stable Integration ───────────────────────────────────────

import { GoogleGenerativeAI } from "@google/generative-ai";

// ─── API KEYS ────────────────────────────────────────────────────────────────
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const genAI2 = new GoogleGenerativeAI(process.env.GEMINI_API_KEY_2);

// ─── MODEL SETUP ─────────────────────────────────────────────────────────────

// Primary → smarter (latest stable)
const primaryModel = genAI.getGenerativeModel({
  model: "gemini-2.5-flash-latest"
});

// Backup → cheaper fallback
const backupModel = genAI2.getGenerativeModel({
  model: "gemini-2.5-flash-lite"
});

// ─── PROMPT BUILDER ──────────────────────────────────────────────────────────
function buildPrompt(
  action: string,
  emailText: string,
  tone: string = "professional"
) {
  return `
You are an AI assistant.

Action: ${action}
Tone: ${tone}

Email Content:
${emailText}

Instructions:
- Be clear and concise
- Maintain proper formatting
- Keep tone consistent
- No unnecessary text
`;
}

// ─── MAIN GENERATE FUNCTION ──────────────────────────────────────────────────
export async function generateResponse({
  action,
  emailText,
  tone = "professional"
}: {
  action: string;
  emailText: string;
  tone?: string;
}) {
  const prompt = buildPrompt(action, emailText, tone);

  try {
    // Try primary model first
    const result = await primaryModel.generateContent(prompt);
    const response = await result.response;
    return response.text();

  } catch (error) {
    console.warn("Primary model failed, switching to backup...", error);

    try {
      const result = await backupModel.generateContent(prompt);
      const response = await result.response;
      return response.text();

    } catch (err) {
      console.error("Both models failed:", err);
      throw new Error("AI generation failed");
    }
  }
}